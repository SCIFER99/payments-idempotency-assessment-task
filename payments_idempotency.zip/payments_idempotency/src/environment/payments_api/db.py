import os
from sqlalchemy import create_engine, Integer, String, Column, ForeignKey, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql+psycopg://postgres:postgres@127.0.0.1:5432/payments')
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class Payment(Base):
    __tablename__ = 'payments'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    amount: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    customer_id: Mapped[str] = mapped_column(String(120), nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False)
    gateway_charge_id: Mapped[str] = mapped_column(String(128), nullable=False)

class PaymentIdempotency(Base):
    __tablename__ = "payment_idempotency"

    id = Column(Integer, primary_key=True)

    idempotency_key = Column(
        String(255),
        nullable=False,
    )

    request_hash = Column(
        String(64),
        nullable=False,
    )

    payment_id = Column(
        Integer,
        ForeignKey("payments.id"),
        nullable=True,
    )

    status = Column(
        String(24),
        nullable=False,
    )

    __table_args__ = (
        UniqueConstraint(
            "idempotency_key",
            name="uq_payment_idempotency_key",
        ),
    )
