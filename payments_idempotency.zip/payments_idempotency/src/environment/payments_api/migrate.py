"""Repeatable additive schema migration for an existing payments table."""
from payments_api.db import Base, engine
from payments_api.main import IdempotencyRecord  # noqa: F401 -- register new table


def migrate():
    Base.metadata.create_all(engine, checkfirst=True)


if __name__ == '__main__':
    migrate()
