import json
import os
from urllib.request import Request, urlopen


def charge(amount: int, currency: str, customer_id: str, *, idempotency_key: str | None = None) -> dict:
    url = os.environ.get('PAYMENT_GATEWAY_URL', 'http://127.0.0.1:8765').rstrip('/') + '/charges'
    headers = {'Content-Type': 'application/json'}
    if idempotency_key is not None:
        headers['Idempotency-Key'] = idempotency_key
    body = json.dumps({'amount': amount, 'currency': currency, 'customer_id': customer_id}).encode()
    request = Request(url, data=body, headers=headers, method='POST')
    with urlopen(request, timeout=5) as response:
        return json.load(response)
