#!/usr/bin/env bash
set -euo pipefail

mkdir -p /logs/verifier

printf '0\n' > /logs/verifier/reward.txt

# Only trusted verifier files at /tests; execute from outside /app to avoid candidate pytest hooks.
unset PYTHONPATH PYTEST_ADDOPTS PYTEST_PLUGINS PYTEST_CURRENT_TEST
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONDONTWRITEBYTECODE=1

cd /tests

# Bootstrap local PostgreSQL without network access (loopback only).
if command -v pg_lsclusters >/dev/null 2>&1; then
  pg_lsclusters --no-header | while read -r v cluster port status rest; do
    if [ "$status" != "online" ]; then pg_ctlcluster "$v" "$cluster" start; fi
  done
fi

su postgres -s /bin/sh -c "psql -tAc \"SELECT 1 FROM pg_roles WHERE rolname='payments'\"" | grep -q 1 || \
 su postgres -s /bin/sh -c "psql -c \"CREATE ROLE payments LOGIN PASSWORD 'payments' CREATEDB\""
su postgres -s /bin/sh -c "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='payments'\"" | grep -q 1 || \
 su postgres -s /bin/sh -c "createdb -O payments payments"

set +e

/usr/local/bin/python -I -m pytest -c /tests/pytest.ini -q /tests/test_outputs.py -ra
rc=$?
set -e
if [ "$rc" -eq 0 ]; then printf '1\n' > /logs/verifier/reward.txt; fi
exit "$rc"
