"""External behavioral verifier. No candidate-controlled test hooks are loaded."""
import concurrent.futures
import importlib
import json
import os
import socket
import subprocess
import sys
import threading
import time
from collections import Counter
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import httpx
import pytest
from sqlalchemy import create_engine, text

# Resolve the project directory automatically
PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Support both Docker and local macOS execution
if Path("/app/payments_api").is_dir():
    APP = Path("/app")
elif (PROJECT_ROOT / "environment" / "payments_api").is_dir():
    APP = PROJECT_ROOT / "environment"
else:
    APP = PROJECT_ROOT

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql+psycopg://postgres:postgres@127.0.0.1:5432/payments_test"
)

AUTH = {"Authorization": "Bearer test-secret"}

BASE = {
    "amount": 5200,
    "currency": "USD",
    "customer_id": "customer-verifier",
}

# Allow Python to import payments_api
sys.path.insert(0, str(APP))



def unused_port():
    with closing(socket.socket()) as s:
        s.bind(('localhost', 0))
        return s.getsockname()[1]


class Ledger:
    def __init__(self):
        self.lock = threading.RLock()
        self.charges = []
        self.idempotency = {}
        self.drop_reply = set()
        self.delay = 0

    def reset(self):
        with self.lock:
            self.charges.clear()
            self.idempotency.clear()
            self.drop_reply.clear()
            self.delay = 0

    def snapshot(self):
        with self.lock:
            return list(self.charges)


@pytest.fixture(scope='session')
def gateway():
    ledger = Ledger()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            if self.path != '/charges':
                self.send_error(404)
                return
            try:
                n = int(self.headers['Content-Length'])
                payload = json.loads(self.rfile.read(n))
            except Exception:
                self.send_error(400)
                return
            key = self.headers.get('Idempotency-Key')
            with ledger.lock:
                if key is not None and key in ledger.idempotency:
                    entry = ledger.idempotency[key]
                    if entry['payload'] != payload:
                        code, reply = 409, {'error': 'gateway idempotency conflict'}
                    else:
                        code, reply = 200, entry['reply']
                else:
                    reply = {'charge_id': f'charge-{len(ledger.charges)+1}', 'status': 'completed'}
                    ledger.charges.append({'key': key, 'payload': payload, 'reply': reply})
                    if key is not None:
                        ledger.idempotency[key] = {'payload': payload, 'reply': reply}
                    code = 201
                drop = key in ledger.drop_reply
                if drop:
                    ledger.drop_reply.remove(key)
                delay = ledger.delay
            if delay:
                time.sleep(delay)
            if drop:
                # A charge succeeded remotely, but the response was lost.
                code, reply = 503, {'error': 'gateway response lost'}
            body = json.dumps(reply).encode()
            self.send_response(code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(('localhost', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield ledger, server.server_address[1]
    server.shutdown()
    server.server_close()


@pytest.fixture(scope='session')
def pg():
    engine = create_engine(DATABASE_URL, pool_pre_ping=True)
    yield engine
    engine.dispose()


def migrate(env):
    run = subprocess.run([sys.executable, '-m', 'payments_api.migrate'],
                         cwd=APP, env=env, capture_output=True, text=True, timeout=30)
    assert run.returncode == 0, f'Database migration failed: {run.stderr}'


@pytest.fixture
def service(gateway, pg):
    ledger, gateway_port = gateway
    ledger.reset()
    # This suite has exclusive use of the test database. Preserve legacy payments
    # and verify that an additive migration operates on that table successfully.
    with pg.begin() as conn:
        conn.execute(text('DROP SCHEMA public CASCADE'))
        conn.execute(text('CREATE SCHEMA public'))
        conn.execute(text('GRANT ALL ON SCHEMA public TO postgres'))
        conn.execute(text('''CREATE TABLE payments (
            id SERIAL PRIMARY KEY, amount INTEGER NOT NULL,
            currency VARCHAR(3) NOT NULL, customer_id VARCHAR(120) NOT NULL,
            status VARCHAR(24) NOT NULL, gateway_charge_id VARCHAR(128) NOT NULL
        )'''))
        conn.execute(text("INSERT INTO payments (amount,currency,customer_id,status,gateway_charge_id) VALUES (111,'USD','legacy','completed','legacy-gw')"))
    env = dict(os.environ, PYTHONPATH=APP, DATABASE_URL=DATABASE_URL,
               PAYMENT_GATEWAY_URL=f'http://localhost:{gateway_port}',
               PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    migrate(env)
    with pg.connect() as conn:
        assert conn.execute(text("SELECT COUNT(*) FROM payments WHERE customer_id='legacy'")).scalar_one() == 1
    procs = []
    ports = [unused_port(), unused_port()]
    try:
        for port in ports:
            proc = subprocess.Popen([sys.executable, '-m', 'uvicorn',
                                     'payments_api.main:app', '--host', 'localhost',
                                     '--port', str(port)], cwd=str(APP), env=env,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            procs.append(proc)
        for port in ports:
            deadline = time.monotonic() + 12
            while time.monotonic() < deadline:
                if all(p.poll() is None for p in procs):
                    try:
                        response = httpx.get(f'http://127.0.0.1:{port}/openapi.json', timeout=0.4)
                        if response.status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                else:
                    failures = []

                    for index, proc in enumerate(procs):
                        if proc.poll() is not None:
                            _, stderr = proc.communicate(timeout=5)
                            failures.append(
                                f"Application process {index + 1} failed.\n"
                                f"Exit code: {proc.returncode}\n"
                                f"STDERR:\n{stderr.decode(errors='replace')}"
                            )

                    raise AssertionError("\n\n".join(failures))
                time.sleep(0.1)
            else:
                raise AssertionError(f'Application did not listen on {port}')
        yield f'http://localhost:{ports[0]}', f'http://localhost:{ports[1]}', ledger, pg, procs
    finally:
        for proc in procs:
            proc.terminate()
        for proc in procs:
            try:
                proc.communicate(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()


def post(url, key=None, payload=None, auth=True):
    headers = dict(AUTH if auth else {})
    if key is not None:
        headers['Idempotency-Key'] = key
    return httpx.post(url + '/payments', json=payload or BASE,
                      headers=headers, timeout=15)


def payments(pg):
    with pg.connect() as c:
        return c.execute(text('SELECT id,amount,currency,customer_id,status,gateway_charge_id FROM payments ORDER BY id')).all()


def assert_only_one_success(service, key):
    _, _, ledger, pg, _ = service

    all_charges = ledger.snapshot()

    print("\nExpected idempotency key:", repr(key))
    print("Gateway ledger:", all_charges)

    charges = [
        x for x in all_charges
        if x["key"] == key
    ]

    assert len(charges) == 1, (
        f"Expected exactly one gateway charge for {key!r}, "
        f"found {len(charges)}. "
        f"Complete ledger: {all_charges}"
    )


def test_completed_replay_exact_response(service):
    a, b, *_ = service
    first = post(a, 'replay-A')
    again = post(b, 'replay-A')
    assert first.status_code == again.status_code == 201
    assert first.json() == again.json()
    assert_only_one_success(service, 'replay-A')


def test_conflict_does_not_mutate_original(service):
    a, b, ledger, pg, _ = service
    first = post(a, 'conflict-A')
    assert first.status_code == 201
    for changed in ({**BASE, 'amount': BASE['amount']+1},
                    {**BASE, 'customer_id': 'a-different-customer'}):
        response = post(b, 'conflict-A', changed)
        assert response.status_code == 409
    assert post(b, 'conflict-A').json() == first.json()
    assert_only_one_success(service, 'conflict-A')


def test_json_key_order_equivalence(service):
    a, b, *_ = service
    original = {'currency': 'USD', 'customer_id': BASE['customer_id'], 'amount': 5200}
    assert post(a, 'order-A', original).status_code == 201
    assert post(b, 'order-A', dict(reversed(list(original.items())))).status_code == 201
    assert_only_one_success(service, 'order-A')


def test_concurrent_cross_process_requests(service):
    a, b, ledger, pg, _ = service
    ledger.delay = 0.35
    def request(i):
        return post((a, b)[i % 2], 'concurrent-A')
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as ex:
        responses = list(ex.map(request, range(16)))
    assert all(r.status_code in (201, 409) for r in responses), [(r.status_code, r.text) for r in responses]
    first = post(a, 'concurrent-A')
    second = post(b, 'concurrent-A')
    assert first.status_code == second.status_code == 201
    assert first.json() == second.json()
    assert_only_one_success(service, 'concurrent-A')


def test_restart_preserves_result(service):
    a, b, ledger, pg, procs = service
    initial = post(a, 'restart-A')
    assert initial.status_code == 201
    procs[0].terminate()
    procs[0].wait(timeout=4)
    retry = post(b, 'restart-A')
    assert retry.status_code == 201
    assert retry.json() == initial.json()
    assert_only_one_success(service, 'restart-A')


def test_ambiguous_gateway_failure_can_recover(service):
    a, b, ledger, pg, _ = service
    ledger.drop_reply.add('ambiguous-A')
    ambiguous = post(a, 'ambiguous-A')
    assert ambiguous.status_code in (409, 502, 503, 504), ambiguous.text
    recovered = post(b, 'ambiguous-A')
    assert recovered.status_code == 201, recovered.text
    assert_only_one_success(service, 'ambiguous-A')
    assert post(a, 'ambiguous-A').json() == recovered.json()


def test_database_write_failure_safe_retry(service):
    a, b, ledger, pg, _ = service
    # Fail all new payment INSERTs, then drop the trigger and retry.
    with pg.begin() as c:
        c.execute(text("CREATE FUNCTION reject_new_payment() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'injected DB insert error'; END; $$"))
        c.execute(text('CREATE TRIGGER reject_new_payment BEFORE INSERT ON payments FOR EACH ROW EXECUTE FUNCTION reject_new_payment()'))
    bad = post(a, 'dbfail-A')
    assert bad.status_code >= 400
    with pg.begin() as c:
        assert c.execute(text("SELECT COUNT(*) FROM payments WHERE customer_id=:customer"), {'customer': BASE['customer_id']}).scalar_one() == 0
        c.execute(text('DROP TRIGGER reject_new_payment ON payments'))
        c.execute(text('DROP FUNCTION reject_new_payment()'))
    good = post(b, 'dbfail-A')
    assert good.status_code == 201, good.text
    assert_only_one_success(service, 'dbfail-A')


def test_legacy_unkeyed_and_distinct_keys(service):
    a, b, ledger, pg, _ = service
    unkeyed = [post(a), post(b)]
    keyed = [post(a, 'different-A'), post(b, 'different-B')]
    assert all(r.status_code == 201 for r in unkeyed + keyed)
    assert len({r.json()['id'] for r in unkeyed + keyed}) == 4
    assert len(ledger.snapshot()) == 4


def test_auth_validation_and_response_contract(service):
    a, b, ledger, pg, _ = service
    assert post(a, 'bad-auth', auth=False).status_code == 401
    assert post(a, 'bad-amount', {**BASE, 'amount': 0}).status_code == 422
    assert post(b, 'bad-currency', {**BASE, 'currency': 'usd'}).status_code == 422
    result = post(a, 'valid-A')
    assert result.status_code == 201
    assert set(result.json()) == {'id', 'amount', 'currency', 'customer_id', 'status', 'gateway_charge_id'}
    assert len(ledger.snapshot()) == 1


def test_migration_repeatable_preserves_existing_rows(service, pg):
    a, b, ledger, pg, _ = service
    env = dict(os.environ, PYTHONPATH=APP, DATABASE_URL=DATABASE_URL)
    migrate(env)
    migrate(env)
    with pg.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM payments WHERE gateway_charge_id='legacy-gw'")).scalar_one() == 1
    assert post(a, 'after-migration-A').status_code == 201
    assert_only_one_success(service, 'after-migration-A')
