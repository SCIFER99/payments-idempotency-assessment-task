#!/usr/bin/env bash

set -euo pipefail

# Locate the directory containing this solve.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Determine the application directory
if [[ -n "${TASK_WORKDIR:-}" ]]; then
    APP_DIR="$TASK_WORKDIR"
elif [[ -d "/app/payments_api" ]]; then
    APP_DIR="/app"
elif [[ -d "$SCRIPT_DIR/../environment/payments_api" ]]; then
    APP_DIR="$(cd "$SCRIPT_DIR/../environment" && pwd)"
else
    echo "ERROR: Cannot locate payments_api directory."
    exit 1
fi

echo "Applying reference solution to: $APP_DIR"

cd "$APP_DIR"

cat > payments_api/main.py <<'PY'
import hashlib
import json
import logging
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import String, ForeignKey, select, text
from sqlalchemy.orm import Mapped, Session, mapped_column

from payments_api.db import Base, Payment, SessionLocal
from payments_api.gateway import charge

logger = logging.getLogger(__name__)
app = FastAPI()


class IdempotencyRecord(Base):
    __tablename__ = 'payment_idempotency'
    key: Mapped[str] = mapped_column(String(255), primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    payment_id: Mapped[int] = mapped_column(ForeignKey('payments.id'), nullable=False, unique=True)


class PaymentRequest(BaseModel):
    amount: int = Field(gt=0)
    currency: str = Field(pattern=r'^[A-Z]{3}$')
    customer_id: str = Field(min_length=1)


class PaymentResponse(BaseModel):
    id: int
    amount: int
    currency: str
    customer_id: str
    status: str
    gateway_charge_id: str


def db_session():
    with SessionLocal() as session:
        yield session


def authenticate(authorization: Annotated[str | None, Header()] = None):
    if authorization != 'Bearer test-secret':
        raise HTTPException(status_code=401, detail='Unauthorized')


def fingerprint(payload: PaymentRequest) -> str:
    canonical = json.dumps(payload.model_dump(mode='json'), sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()


def saved_response(row: Payment) -> PaymentResponse:
    return PaymentResponse(id=row.id, amount=row.amount, currency=row.currency,
                           customer_id=row.customer_id, status=row.status,
                           gateway_charge_id=row.gateway_charge_id)


@app.post('/payments', response_model=PaymentResponse, status_code=201,
          dependencies=[Depends(authenticate)])
def create_payment(data: PaymentRequest,
                   idempotency_key: Annotated[str | None, Header(alias='Idempotency-Key')] = None,
                   session: Session = Depends(db_session)):
    if idempotency_key is not None and (not idempotency_key.strip() or len(idempotency_key) > 255):
        raise HTTPException(status_code=400, detail='Invalid Idempotency-Key')

    if idempotency_key is None:
        # Historical behavior: each request independently creates a payment.
        receipt = charge(data.amount, data.currency, data.customer_id)
        item = Payment(amount=data.amount, currency=data.currency,
                       customer_id=data.customer_id, status=receipt['status'],
                       gateway_charge_id=receipt['charge_id'])
        session.add(item)
        session.commit()
        session.refresh(item)
        return saved_response(item)

    digest = fingerprint(data)
    # A stable, database-scoped transactional advisory lock serializes competing
    # requests across processes. Hash collisions only reduce concurrency; they
    # never compromise correctness because record keys are compared exactly.
    # No separate check-then-insert race, and no process-local memory.
    lock_id = int.from_bytes(hashlib.sha256(idempotency_key.encode()).digest()[:8], 'big', signed=True)
    try:
        locked = session.execute(text('SELECT pg_try_advisory_xact_lock(:id)'),
                                 {'id': lock_id}).scalar_one()
        if not locked:
            logger.info('payment attempt pending for key_digest=%s', hashlib.sha256(idempotency_key.encode()).hexdigest()[:12])
            raise HTTPException(status_code=409, detail='Payment pending; retry with same key')

        prior = session.execute(select(IdempotencyRecord).where(
            IdempotencyRecord.key == idempotency_key)).scalar_one_or_none()
        if prior is not None:
            if prior.fingerprint != digest:
                logger.info('conflicting payment attempt')
                raise HTTPException(status_code=409, detail='Idempotency-Key conflict')
            payment = session.get(Payment, prior.payment_id)
            logger.info('replayed completed payment id=%s', payment.id)
            return saved_response(payment)

        # If the gateway committed but our DB transaction did not, reusing the
        # same external gateway key recovers its original charge without a new one.
        receipt = charge(data.amount, data.currency, data.customer_id,
                         idempotency_key=idempotency_key)
        item = Payment(amount=data.amount, currency=data.currency,
                       customer_id=data.customer_id, status=receipt['status'],
                       gateway_charge_id=receipt['charge_id'])
        session.add(item)
        session.flush()
        session.add(IdempotencyRecord(key=idempotency_key,
                                      fingerprint=digest, payment_id=item.id))
        session.commit()
        logger.info('completed payment id=%s', item.id)
        return saved_response(item)
    except HTTPException:
        session.rollback()
        raise
    except Exception:
        session.rollback()
        logger.exception('payment attempt failed or interrupted')
        raise HTTPException(status_code=502, detail='Payment temporarily unavailable; retry')
PY
cat > payments_api/migrate.py <<'PY'
"""Repeatable additive schema migration for an existing payments table."""
from payments_api.db import Base, engine
from payments_api.main import IdempotencyRecord  # noqa: F401 -- register new table


def migrate():
    Base.metadata.create_all(engine, checkfirst=True)


if __name__ == '__main__':
    migrate()
PY
# Supporting human-readable SQL migration; migration runner executes equivalent
# SQL via SQLAlchemy metadata, tolerating preexisting payment rows.
mkdir -p migrations
cat > migrations/001_payment_idempotency.sql <<'SQL'
CREATE TABLE IF NOT EXISTS payment_idempotency (
    key VARCHAR(255) PRIMARY KEY,
    fingerprint VARCHAR(64) NOT NULL,
    payment_id INTEGER NOT NULL UNIQUE REFERENCES payments(id)
);
SQL
