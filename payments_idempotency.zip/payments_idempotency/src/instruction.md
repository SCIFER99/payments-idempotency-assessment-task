# Implement reliable payment idempotency

You are working in `/app`, a Python 3.12 FastAPI and SQLAlchemy service backed by PostgreSQL. The existing `POST /payments` calls an idempotency-capable payment gateway, but retries may create multiple charges or payment rows. Read `/app/README.md` for the existing API contract and gateway behavior.

Implement the following behavior without changing unrelated endpoints:

1. A valid `Idempotency-Key` header makes equivalent retries of the same payment request create at most one successful gateway charge and one payment row.
2. Replaying a completed request with the same key and equivalent payload returns the original HTTP 201 response body, including payment ID and status.
3. Reusing that key with a different payment payload returns HTTP 409 without another charge or modified payment.
4. Concurrent requests sharing a key, including requests handled by separate service processes, must not duplicate the charge or payment. Requests still in progress may return HTTP 409 with a clear retryable/pending indication; a subsequent retry must eventually obtain the original result.
5. Durable idempotency state survives application restarts. A crash or gateway timeout after an external charge succeeded must permit recovery using the gateway's idempotency capability rather than making a second charge.
6. Failed database transactions must not expose a falsely successful local payment or permanently prevent safe retries.
7. Without the header, preserve the current behavior: every valid POST creates a distinct payment.
8. Preserve existing HTTP authentication, validation, response schema, and unrelated behavior.
9. Provide a repeatable database migration compatible with an existing populated `payments` table, and operationally useful diagnostics for pending, completed, conflicting, and failed attempts.

Constraints: Do not replace the production gateway adapter with a mock, rely on process memory for correctness, disable tests, or access external networks. Use dependencies already available in the image. You are responsible for exploring the repository, choosing the concurrency and recovery design, implementing it, and testing it. No verifier files are part of the editable task.
